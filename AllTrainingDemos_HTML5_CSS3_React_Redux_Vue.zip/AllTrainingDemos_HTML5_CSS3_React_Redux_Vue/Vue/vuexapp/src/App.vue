<template>
  <div id="app">
   <ListOfCourses></ListOfCourses>
  </div>
</template>

<script>
import ListOfCourses from './components/listofcourses.component';


export default {
  name: 'app',
  components: {
    ListOfCourses
  }
}
</script>

<style>

</style>
